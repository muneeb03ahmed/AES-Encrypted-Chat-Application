import { useState, useRef, useEffect } from "react";
import { encrypt, decrypt, generateKey, toHex, type EncryptedPayload } from "@/lib/aes";
import { Lock, Unlock, Send, Shield, Terminal, Key, RefreshCw } from "lucide-react";

interface LogEntry {
  id: number;
  timestamp: string;
  sender: "alice" | "bob" | "server";
  type: "encrypt" | "decrypt" | "relay" | "info";
  plaintext?: string;
  payload?: EncryptedPayload;
  decrypted?: string;
}

interface Message {
  id: number;
  sender: "alice" | "bob";
  plaintext: string;
  payload: EncryptedPayload;
}

const EncryptedChat = () => {
  const [sharedKey] = useState(() => generateKey());
  const [messages, setMessages] = useState<Message[]>([]);
  const [aliceInput, setAliceInput] = useState("");
  const [bobInput, setBobInput] = useState("");
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showCiphertext, setShowCiphertext] = useState(true);
  const logRef = useRef<HTMLDivElement>(null);
  const chatRef = useRef<HTMLDivElement>(null);
  const logIdRef = useRef(0);
  const msgIdRef = useRef(0);

  useEffect(() => {
    logRef.current?.scrollTo(0, logRef.current.scrollHeight);
  }, [logs]);

  useEffect(() => {
    chatRef.current?.scrollTo(0, chatRef.current.scrollHeight);
  }, [messages]);

  const addLog = (entry: Omit<LogEntry, "id" | "timestamp">) => {
    setLogs((prev) => [
      ...prev,
      {
        ...entry,
        id: logIdRef.current++,
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
      },
    ]);
  };

  const handleSend = async (sender: "alice" | "bob", text: string) => {
    if (!text.trim()) return;

    // Step 1: Encrypt
    const payload = await encrypt(text, sharedKey);
    addLog({ sender, type: "encrypt", plaintext: text, payload });

    // Step 2: Server relays (simulated)
    addLog({ sender: "server", type: "relay", payload });

    // Step 3: Recipient decrypts
    const recipient = sender === "alice" ? "bob" : "alice";
    const decrypted = await decrypt(payload, sharedKey);
    addLog({ sender: recipient, type: "decrypt", payload, decrypted });

    const msg: Message = {
      id: msgIdRef.current++,
      sender,
      plaintext: text,
      payload,
    };
    setMessages((prev) => [...prev, msg]);

    if (sender === "alice") setAliceInput("");
    else setBobInput("");
  };

  return (
    <div className="min-h-screen bg-background font-mono text-foreground flex flex-col">
      {/* Header */}
      <header className="border-b border-border px-6 py-4 flex items-center gap-3">
        <Shield className="w-6 h-6 text-primary" />
        <h1 className="font-display text-xl font-bold tracking-wider text-primary">
          AES-ENCRYPTED CHAT
        </h1>
        <span className="text-xs text-muted-foreground ml-2">// CBC MODE · 128-BIT · PKCS7</span>
        <div className="ml-auto flex items-center gap-4">
          <button
            onClick={() => setShowCiphertext(!showCiphertext)}
            className="flex items-center gap-2 text-xs px-3 py-1.5 rounded border border-border hover:border-primary transition-colors text-muted-foreground hover:text-primary"
          >
            {showCiphertext ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
            {showCiphertext ? "HIDE CIPHER" : "SHOW CIPHER"}
          </button>
        </div>
      </header>

      {/* Key display */}
      <div className="border-b border-border px-6 py-2 flex items-center gap-2 text-xs">
        <Key className="w-3 h-3 text-cipher" />
        <span className="text-muted-foreground">PRE-SHARED KEY:</span>
        <code className="text-cipher font-bold tracking-wider">{toHex(sharedKey)}</code>
        <span className="text-muted-foreground ml-4">// 128-bit AES key shared between Alice & Bob</span>
      </div>

      <div className="flex-1 flex min-h-0">
        {/* Chat area */}
        <div className="flex-1 flex flex-col border-r border-border">
          {/* Messages */}
          <div ref={chatRef} className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && (
              <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                <div className="text-center space-y-2">
                  <Terminal className="w-8 h-8 mx-auto opacity-50" />
                  <p>No messages yet. Send one below.</p>
                  <p className="text-xs">Messages are AES-CBC encrypted with a random IV per message.</p>
                </div>
              </div>
            )}
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col gap-1 ${msg.sender === "alice" ? "items-start" : "items-end"}`}
              >
                <span className={`text-xs font-bold tracking-wider ${msg.sender === "alice" ? "text-primary" : "text-accent"}`}>
                  {msg.sender === "alice" ? "▶ ALICE" : "◀ BOB"}
                </span>
                <div className={`max-w-md rounded px-3 py-2 border ${
                  msg.sender === "alice"
                    ? "bg-secondary border-primary/30"
                    : "bg-secondary border-accent/30"
                }`}>
                  <p className="text-sm">{msg.plaintext}</p>
                </div>
                {showCiphertext && (
                  <div className="max-w-md text-[10px] text-cipher/70 font-mono break-all leading-tight px-1">
                    <span className="text-muted-foreground">IV:</span> {msg.payload.iv}
                    <br />
                    <span className="text-muted-foreground">CT:</span> {msg.payload.ciphertext}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Input area - two panels */}
          <div className="border-t border-border grid grid-cols-2 divide-x divide-border">
            {/* Alice */}
            <div className="p-3">
              <div className="text-xs text-primary font-bold mb-1 tracking-wider">ALICE</div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend("alice", aliceInput);
                }}
                className="flex gap-2"
              >
                <input
                  value={aliceInput}
                  onChange={(e) => setAliceInput(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 bg-input border border-border rounded px-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
                />
                <button
                  type="submit"
                  className="p-1.5 rounded bg-primary text-primary-foreground hover:opacity-80 transition-opacity"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
            {/* Bob */}
            <div className="p-3">
              <div className="text-xs text-accent font-bold mb-1 tracking-wider">BOB</div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend("bob", bobInput);
                }}
                className="flex gap-2"
              >
                <input
                  value={bobInput}
                  onChange={(e) => setBobInput(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 bg-input border border-border rounded px-3 py-1.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent transition-colors"
                />
                <button
                  type="submit"
                  className="p-1.5 rounded bg-accent text-accent-foreground hover:opacity-80 transition-opacity"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Server log panel */}
        <div className="w-96 flex flex-col bg-card">
          <div className="px-4 py-3 border-b border-border flex items-center gap-2">
            <Terminal className="w-4 h-4 text-server" />
            <span className="text-xs font-bold tracking-wider text-server">SERVER LOG</span>
            <span className="text-[10px] text-muted-foreground ml-auto">{logs.length} entries</span>
          </div>
          <div ref={logRef} className="flex-1 overflow-y-auto p-3 space-y-2 text-[11px]">
            {logs.map((log) => (
              <div key={log.id} className="border border-border/50 rounded p-2 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">{log.timestamp}</span>
                  <span
                    className={`font-bold uppercase tracking-wider ${
                      log.type === "encrypt"
                        ? "text-primary"
                        : log.type === "decrypt"
                        ? "text-accent"
                        : log.type === "relay"
                        ? "text-server"
                        : "text-muted-foreground"
                    }`}
                  >
                    {log.type === "encrypt" && `🔒 ${log.sender} ENCRYPT`}
                    {log.type === "decrypt" && `🔓 ${log.sender} DECRYPT`}
                    {log.type === "relay" && "📡 SERVER RELAY"}
                    {log.type === "info" && "ℹ INFO"}
                  </span>
                </div>
                {log.plaintext && (
                  <div>
                    <span className="text-muted-foreground">plain: </span>
                    <span className="text-foreground">"{log.plaintext}"</span>
                  </div>
                )}
                {log.payload && (
                  <>
                    <div className="break-all">
                      <span className="text-muted-foreground">iv: </span>
                      <span className="text-cipher">{log.payload.iv}</span>
                    </div>
                    <div className="break-all">
                      <span className="text-muted-foreground">ct: </span>
                      <span className="text-cipher">{log.payload.ciphertext}</span>
                    </div>
                  </>
                )}
                {log.decrypted && (
                  <div>
                    <span className="text-muted-foreground">decrypted: </span>
                    <span className="text-foreground">"{log.decrypted}"</span>
                  </div>
                )}
              </div>
            ))}
            {logs.length === 0 && (
              <div className="text-muted-foreground text-center py-8">
                Waiting for messages...
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EncryptedChat;
