/**
 * AES-CBC encryption/decryption using the Web Crypto API.
 * - 128-bit key (16 bytes)
 * - Random 16-byte IV per message
 * - PKCS7 padding handled natively by SubtleCrypto
 */

export function generateKey(): Uint8Array {
  return crypto.getRandomValues(new Uint8Array(16));
}

export function generateIV(): Uint8Array {
  return crypto.getRandomValues(new Uint8Array(16));
}

export function toHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function fromHex(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

export function toBase64(bytes: Uint8Array): string {
  return btoa(String.fromCharCode(...bytes));
}

async function importKey(raw: Uint8Array): Promise<CryptoKey> {
  return crypto.subtle.importKey("raw", raw.buffer as ArrayBuffer, { name: "AES-CBC" }, false, [
    "encrypt",
    "decrypt",
  ]);
}

export interface EncryptedPayload {
  iv: string; // hex
  ciphertext: string; // base64
}

export async function encrypt(
  plaintext: string,
  keyBytes: Uint8Array
): Promise<EncryptedPayload> {
  const iv = generateIV();
  const key = await importKey(keyBytes);
  const encoded = new TextEncoder().encode(plaintext);
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-CBC", iv: iv.buffer as ArrayBuffer },
    key,
    encoded
  );
  return {
    iv: toHex(iv),
    ciphertext: toBase64(new Uint8Array(encrypted)),
  };
}

export async function decrypt(
  payload: EncryptedPayload,
  keyBytes: Uint8Array
): Promise<string> {
  const iv = fromHex(payload.iv);
  const key = await importKey(keyBytes);
  const cipherBytes = Uint8Array.from(atob(payload.ciphertext), (c) =>
    c.charCodeAt(0)
  );
  const decrypted = await crypto.subtle.decrypt(
    { name: "AES-CBC", iv: iv.buffer as ArrayBuffer },
    key,
    cipherBytes
  );
  return new TextDecoder().decode(decrypted);
}
